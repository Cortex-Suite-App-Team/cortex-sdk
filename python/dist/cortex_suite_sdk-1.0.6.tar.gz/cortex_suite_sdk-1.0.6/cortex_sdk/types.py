from __future__ import annotations

from typing import Callable, Literal

from typing_extensions import TypedDict, NotRequired


class RuntimeBootstrap(TypedDict):
    execution_mode: str
    bundle_url: str
    checksum: str
    artifact_id: NotRequired[str | None]
    artifact_kind: NotRequired[str | None]
    run_mode: NotRequired[str | None]
    trigger_payload: NotRequired[dict[str, object] | None]


class AuthTokenResponse(TypedDict):
    ws_url: str
    access_token: str
    refresh_token: str
    runtime_bootstrap: RuntimeBootstrap


class CortexMessage(TypedDict):
    type: str
    schema: str
    session_id: str
    seq: NotRequired[int | None]
    payload: dict[str, object]
    meta: NotRequired[dict[str, object] | None]
    ts: str


SessionState = Literal[
    "CREATED",
    "INITIALIZING",
    "ACTIVE",
    "WAITING",
    "COMPLETED",
    "FAILED",
    "STOPPED",
    "TIMEOUT",
    "CANCELLED",
]

ChannelState = Literal[
    "CONNECTING",
    "OPEN",
    "STALE",
    "RECONNECTING",
    "CLOSED",
    "AUTH_FAILED",
]

MessageCallback = Callable[["CortexMessage"], None]
