from __future__ import annotations

import json
from typing import Callable

from .constants import SCHEMA_VERSION
from .errors import make_error, lookup_error, CortexError
from .transport import Transport
from .types import CortexMessage, RuntimeBootstrap, SessionState


_TERMINAL_STATES: set[SessionState] = {
    "COMPLETED",
    "FAILED",
    "STOPPED",
    "TIMEOUT",
    "CANCELLED",
}
_LIFECYCLE_STATE_MAP: dict[str, SessionState] = {
    "active": "ACTIVE",
    "waiting": "WAITING",
    "completed": "COMPLETED",
    "failed": "FAILED",
    "stopped": "STOPPED",
    "timeout": "TIMEOUT",
    "cancelled": "CANCELLED",
}


class SessionManager:
    """Manages session state and envelope construction/parsing."""

    def __init__(
        self,
        on_message: Callable[[CortexMessage], None],
        on_fatal_error: Callable[[CortexError], None],
    ) -> None:
        self._on_message = on_message
        self._on_fatal_error = on_fatal_error

        self._session_id: str | None = None
        self._session_state: SessionState = "CREATED"
        self._last_seq: int = 0
        self._transport: Transport | None = None
        self._send_timeout: float = 10.0

    def _set_session_state(self, next_state: SessionState) -> None:
        if self._session_state in _TERMINAL_STATES and self._session_state != next_state:
            return
        self._session_state = next_state

    # ── accessors ─────────────────────────────────────────────────────────────

    @property
    def session_id(self) -> str | None:
        return self._session_id

    @property
    def session_state(self) -> SessionState:
        return self._session_state

    @property
    def last_seq(self) -> int:
        return self._last_seq

    # ── configuration ─────────────────────────────────────────────────────────

    def set_transport(self, transport: Transport, send_timeout: float) -> None:
        self._transport = transport
        self._send_timeout = send_timeout

    # ── outbound helpers ──────────────────────────────────────────────────────

    def _build_envelope(
        self, type_: str, payload: dict[str, object]
    ) -> dict[str, object]:
        env: dict[str, object] = {
            "type": type_,
            "schema": SCHEMA_VERSION,
            "payload": payload,
            "ts": _now_iso(),
        }
        if self._session_id:
            env["session_id"] = self._session_id
        return env

    async def _send(self, envelope: dict[str, object]) -> None:
        if self._transport is None:
            raise make_error("transport_send_timeout", "No transport configured")
        await self._transport.send(envelope)

    async def send_init(self, bootstrap: RuntimeBootstrap) -> None:
        """Send system::init — intentionally omits session_id."""
        self._session_state = "INITIALIZING"
        envelope: dict[str, object] = {
            "type": "system::init",
            "schema": SCHEMA_VERSION,
            "payload": dict(bootstrap),
            "ts": _now_iso(),
        }
        await self._send(envelope)

    async def send_resync(self) -> None:
        await self._send(
            self._build_envelope("system::resync", {"last_seq": self._last_seq})
        )

    async def send_stop(self) -> None:
        await self._send(self._build_envelope("sandbox::stop", {}))

    async def send_chat_message(
        self, content: str, attachments: list[str] | None
    ) -> None:
        payload: dict[str, object] = {"content": content, "role": "user"}
        if attachments:
            payload["attachments"] = attachments
        await self._send(self._build_envelope("chat::message", payload))

    # ── inbound handling ──────────────────────────────────────────────────────

    def handle_incoming(self, raw: str) -> None:
        """Parse a raw JSON frame and dispatch callbacks."""
        try:
            parsed: dict[str, object] = json.loads(raw)
            msg: CortexMessage = parsed  # type: ignore[assignment]
        except Exception:
            return  # malformed frame — ignore

        # Learn session_id from first server message
        if not self._session_id and msg.get("session_id"):
            self._session_id = msg["session_id"]
            if self._session_state not in _TERMINAL_STATES:
                self._session_state = "ACTIVE"

        # Track highest sequence number
        seq = msg.get("seq")
        if isinstance(seq, int) and seq > self._last_seq:
            self._last_seq = seq

        self._update_session_state(msg)

        # Fatal error detection
        if msg.get("type") == "system::error":
            self._handle_system_error(msg["payload"])

        self._on_message(msg)

    def _handle_system_error(self, payload: dict[str, object]) -> None:
        code = payload.get("code", "session_terminal")
        message = payload.get("message", "Runtime error")
        entry = lookup_error(str(code))
        if entry and entry.fatal:
            self._set_session_state("FAILED")
            err = make_error(str(code), str(message))
            self._on_fatal_error(err)

    def _update_session_state(self, msg: CortexMessage) -> None:
        msg_type = msg.get("type")

        if msg_type == "sandbox::snapshot":
            state = msg["payload"].get("state")
            if isinstance(state, str) and state.lower() == "waiting":
                self._set_session_state("WAITING")
            return

        if msg_type == "sandbox::lifecycle":
            status = msg["payload"].get("status")
            if isinstance(status, str):
                next_state = _LIFECYCLE_STATE_MAP.get(status.lower())
                if next_state is not None:
                    self._set_session_state(next_state)
            return

        if msg_type == "system::error":
            code = msg["payload"].get("code")
            if isinstance(code, str):
                entry = lookup_error(code)
                if entry and entry.fatal:
                    self._set_session_state("FAILED")


def _now_iso() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()
