"""
file_upload transcript:
init → [HTTP upload → attachment_id] → chat::message with attachments → chat::answer
"""
from __future__ import annotations

import pytest
import websockets

from .helpers import make_client, wait_for
from .mock_server import FIXED_ATTACHMENT_ID, FIXED_SESSION_ID, MockServer, start_mock_server


@pytest.mark.asyncio
async def test_file_upload() -> None:
    async def on_ws_message(
        msg: dict,
        ws: websockets.WebSocketServerProtocol,
        srv: MockServer,
    ) -> None:
        if msg.get("type") == "chat::message":
            await srv.send_to(ws, {
                "type": "chat::answer",
                "schema": "1.0",
                "session_id": FIXED_SESSION_ID,
                "seq": 1,
                "payload": {
                    "content": "The document covers three main topics.",
                    "role": "assistant",
                    "answer_kind": "final",
                    "turn_id": "turn_006",
                },
                "ts": "2026-04-04T00:00:00Z",
            })

    server = await start_mock_server(
        auto_chat_answer=False,
        auto_init_echo=True,
        on_ws_message=on_ws_message,
    )

    received = []
    client = make_client(server, received)

    try:
        await client.connect()
        await wait_for(lambda: client.session_id is not None)

        # Upload a file (bytes)
        attachment_id = await client.upload_attachment(b"\x00\x01\x02\x03")
        assert attachment_id == FIXED_ATTACHMENT_ID

        # Send message with attachment reference
        await client.send_message(
            "Please summarize this document.",
            attachments=[attachment_id],
        )

        await wait_for(
            lambda: any(
                m["type"] == "chat::answer" and m["payload"].get("answer_kind") == "final"
                for m in received
            ),
            timeout=3.0,
        )

        # Verify chat::message payload includes attachment
        chat_msg = next(m for m in server.received if m["type"] == "chat::message")
        payload = chat_msg["payload"]
        assert payload["attachments"] == [FIXED_ATTACHMENT_ID]  # type: ignore[index]
        assert payload["content"] == "Please summarize this document."  # type: ignore[index]

        answer = next(
            m for m in received
            if m["type"] == "chat::answer" and m["payload"].get("answer_kind") == "final"
        )
        assert answer["payload"]["turn_id"] == "turn_006"
    finally:
        await client.disconnect()
        await server.close()
